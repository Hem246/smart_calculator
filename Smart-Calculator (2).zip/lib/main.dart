import 'package:flutter/material.dart';
import 'package:math_expressions/math_expressions.dart';
import 'package:flutter/services.dart'; // Add this line for Clipboard support

void main() {
  runApp(SmartCalculator());
}

class SmartCalculator extends StatefulWidget {
  @override
  _SmartCalculatorState createState() => _SmartCalculatorState();
}

class _SmartCalculatorState extends State<SmartCalculator> {
  String _output = '';
  String _expression = '';
  String currentMode = 'Basic'; // Default mode
  String _lastInput = '';
  List<String> _history = []; // List to store calculation history

  TextEditingController _editingController = TextEditingController();
  FocusNode _focusNode = FocusNode();

  // Function to handle button press
  void _buttonPressed(String buttonText) {
    setState(() {
      if (_editingController.text == 'Enter expression') {
        _editingController.clear(); // Clear placeholder text
      }

      TextSelection selection = _editingController.selection;
      String text = _editingController.text;

      // Handle the case when the user types an operator and prevent multiple operators
      if (_isOperator(buttonText)) {
        if (_expression.isNotEmpty &&
            _isOperator(_expression.substring(_expression.length - 1))) {
          _expression = _expression.substring(0, _expression.length - 1);
        }
        _expression += buttonText;
      } else if (buttonText == 'C') {
        _expression = '';
        _output = '';
      } else if (buttonText == '🔙') {
        // Handle back button: Delete last character or selected text
        if (selection.isCollapsed) {
          // If no text is selected, delete last character
          if (_expression.isNotEmpty) {
            _expression = _expression.substring(0, _expression.length - 1);
          }
        } else {
          // If text is selected, delete the selected text
          _expression = text.substring(0, selection.start) +
              text.substring(selection.end);
        }
      } else if (buttonText == '=') {
        _calculateResult();
      } else if (buttonText == '.') {
        if (_expression.isEmpty ||
            _isOperator(_expression.substring(_expression.length - 1))) {
          _expression += '0.';
        } else {
          _expression += buttonText;
        }
      } else if (buttonText == '00') {
        if (_expression == '' || _expression == '0') {
          _expression = '0';
        } else if (_expression.endsWith('0') || _expression.endsWith('00')) {
          _expression = _expression.substring(0, _expression.length - 1) + '00';
        } else {
          _expression += '00';
        }
      } else {
        _expression =
            text.replaceRange(selection.start, selection.end, buttonText);
      }

      _editingController.text = _expression;
      _editingController.selection =
          TextSelection.collapsed(offset: _expression.length);

      _lastInput = buttonText;
    });
  }

  // Function to calculate the result using math_expressions package
  void _calculateResult() {
    try {
      Parser parser = Parser();
      Expression exp = parser.parse(_expression
          .replaceAll('÷', '/')
          .replaceAll('×', '*')
          .replaceAll('%', '/100'));
      ContextModel contextModel = ContextModel();
      double evalResult = exp.evaluate(EvaluationType.REAL, contextModel);
      _output =
          evalResult.toStringAsFixed(2); // Format result to two decimal places
      _history.add('$_expression = $_output'); // Save history
    } catch (e) {
      _output = 'Error';
    }
  }

  // Function to handle the mode change
  void _changeMode(String newMode) {
    setState(() {
      currentMode = newMode;
    });
  }

  // Check if the input is an operator
  bool _isOperator(String value) {
    return ['+', '-', '×', '÷', '%'].contains(value);
  }

  // Function to clear history
  void _clearHistory() {
    setState(() {
      _history.clear();
    });
  }

  // Function to copy result to clipboard
  void _copyToClipboard() {
    Clipboard.setData(ClipboardData(text: _output));
  }

  // Print preview dialog
  void _showPrintPreview() {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text('Print Preview'),
          content: SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('Expression: $_expression'),
                Text('Result: $_output'),
                SizedBox(height: 20),
                Text('History:'),
                for (var entry in _history)
                  Text(entry, style: TextStyle(fontSize: 14)),
              ],
            ),
          ),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.of(context).pop(); // Close preview
              },
              child: Text('Close'),
            ),
            TextButton(
              onPressed: () {
                _printCalculation(); // Trigger print functionality
                Navigator.of(context).pop(); // Close preview
              },
              child: Text('Print'),
            ),
          ],
        );
      },
    );
  }

  // Print the calculation (simulated, as actual printing requires platform-specific code)
  void _printCalculation() {
    // Here you would integrate actual printing functionality for Android/iOS.
    // Currently, it just simulates the print action.
    print('Printing: $_expression = $_output');
    for (var entry in _history) {
      print('History: $entry');
    }
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Smart Calculator',
      theme: ThemeData.dark(),
      home: Scaffold(
        appBar: AppBar(
          title: Row(
            children: [
              Image.asset(
                'assets/images/logo.png',
                width: 40,
                height: 40,
              ),
              SizedBox(width: 10),
              Text('Smart Calculator'),
            ],
          ),
        ),
        drawer: Drawer(
          child: ListView(
            children: <Widget>[
              ListTile(
                title: Text('Basic Mode'),
                onTap: () => _changeMode('Basic'),
              ),
              ListTile(
                title: Text('Student Mode'),
                onTap: () => _changeMode('Student'),
              ),
              ListTile(
                title: Text('Advanced Mode'),
                onTap: () => _changeMode('Advanced'),
              ),
            ],
          ),
        ),
        body: Column(
          mainAxisAlignment: MainAxisAlignment.end,
          children: <Widget>[
            Padding(
              padding: const EdgeInsets.all(10.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  // Editable expression
                  Container(
                    height: 80,
                    child: TextField(
                      controller: _editingController,
                      focusNode: _focusNode,
                      style:
                          TextStyle(fontSize: 28, fontWeight: FontWeight.bold),
                      textAlign: TextAlign.right,
                      keyboardType: TextInputType.text,
                      decoration: InputDecoration(
                        border: InputBorder.none,
                        hintText: '',
                      ),
                      onChanged: (text) {
                        setState(() {
                          _expression = text;
                        });
                      },
                    ),
                  ),
                  // Display last input and answer
                  SingleChildScrollView(
                    scrollDirection: Axis.horizontal,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.end,
                      children: [
                        Text(
                          _lastInput,
                          style: TextStyle(
                              fontSize: 18, fontWeight: FontWeight.normal),
                        ),
                        Text(
                          _output,
                          style: TextStyle(
                              fontSize: 24,
                              fontWeight: FontWeight.bold,
                              color: Colors.blue),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            // Calculator Buttons
            Expanded(
              child: currentMode == 'Basic'
                  ? SingleChildScrollView(
                      child: Column(
                        children: [
                          GridView.builder(
                            shrinkWrap: true,
                            physics: NeverScrollableScrollPhysics(),
                            gridDelegate:
                                SliverGridDelegateWithFixedCrossAxisCount(
                              crossAxisCount: 4,
                              crossAxisSpacing: 5.0,
                              mainAxisSpacing: 5.0,
                              childAspectRatio: 1.4, // Adjusted aspect ratio
                            ),
                            itemCount: _getButtonList(currentMode).length,
                            itemBuilder: (context, index) {
                              String buttonText =
                                  _getButtonList(currentMode)[index];
                              return ElevatedButton(
                                onPressed: () {
                                  _buttonPressed(buttonText);
                                },
                                style: ElevatedButton.styleFrom(
                                  shape: RoundedRectangleBorder(
                                      borderRadius: BorderRadius.circular(8.0)),
                                  backgroundColor: _getButtonColor(buttonText),
                                  padding: EdgeInsets.symmetric(
                                      vertical: 5, horizontal: 5),
                                ),
                                child: Text(
                                  buttonText,
                                  style: TextStyle(
                                    fontSize: 20, // Adjusted font size
                                    fontWeight: FontWeight.bold,
                                    color: Colors.white,
                                  ),
                                ),
                              );
                            },
                          ),
                        ],
                      ),
                    )
                  : currentMode == 'Student'
                      ? SingleChildScrollView(
                          child: Column(
                            children: [
                              GridView.builder(
                                shrinkWrap: true,
                                physics: NeverScrollableScrollPhysics(),
                                gridDelegate:
                                    SliverGridDelegateWithFixedCrossAxisCount(
                                  crossAxisCount: 4,
                                  crossAxisSpacing: 5.0,
                                  mainAxisSpacing: 5.0,
                                  childAspectRatio:
                                      1.4, // Adjusted aspect ratio
                                ),
                                itemCount: _getButtonList(currentMode).length,
                                itemBuilder: (context, index) {
                                  String buttonText =
                                      _getButtonList(currentMode)[index];
                                  return ElevatedButton(
                                    onPressed: () {
                                      _buttonPressed(buttonText);
                                    },
                                    style: ElevatedButton.styleFrom(
                                      shape: RoundedRectangleBorder(
                                          borderRadius:
                                              BorderRadius.circular(8.0)),
                                      backgroundColor:
                                          _getButtonColor(buttonText),
                                      padding: EdgeInsets.symmetric(
                                          vertical: 5, horizontal: 5),
                                    ),
                                    child: Text(
                                      buttonText,
                                      style: TextStyle(
                                        fontSize: 20, // Adjusted font size
                                        fontWeight: FontWeight.bold,
                                        color: Colors.white,
                                      ),
                                    ),
                                  );
                                },
                              ),
                            ],
                          ),
                        )
                      : currentMode == 'Advanced'
                          ? SingleChildScrollView(
                              child: Column(
                                children: [
                                  GridView.builder(
                                    shrinkWrap: true,
                                    physics: NeverScrollableScrollPhysics(),
                                    gridDelegate:
                                        SliverGridDelegateWithFixedCrossAxisCount(
                                      crossAxisCount: 4,
                                      crossAxisSpacing: 5.0,
                                      mainAxisSpacing: 5.0,
                                      childAspectRatio: 1.4,
                                    ),
                                    itemCount:
                                        _getButtonList(currentMode).length,
                                    itemBuilder: (context, index) {
                                      String buttonText =
                                          _getButtonList(currentMode)[index];
                                      return ElevatedButton(
                                        onPressed: () {
                                          _buttonPressed(buttonText);
                                        },
                                        style: ElevatedButton.styleFrom(
                                          shape: RoundedRectangleBorder(
                                              borderRadius:
                                                  BorderRadius.circular(8.0)),
                                          backgroundColor:
                                              _getButtonColor(buttonText),
                                          padding: EdgeInsets.symmetric(
                                              vertical: 5, horizontal: 5),
                                        ),
                                        child: Text(
                                          buttonText,
                                          style: TextStyle(
                                            fontSize: 20,
                                            fontWeight: FontWeight.bold,
                                            color: Colors.white,
                                          ),
                                        ),
                                      );
                                    },
                                  ),
                                ],
                              ),
                            )
                          : SizedBox.shrink(),
            ),
            // Print and History
            Padding(
              padding: const EdgeInsets.only(bottom: 20.0),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  IconButton(
                    icon: Icon(Icons.print),
                    onPressed: _showPrintPreview,
                  ),
                  IconButton(
                    icon: Icon(Icons.history),
                    onPressed: () {
                      showDialog(
                        context: context,
                        builder: (BuildContext context) {
                          return AlertDialog(
                            title: Text('Calculation History'),
                            content: SingleChildScrollView(
                              child: Column(
                                children: [
                                  for (var entry in _history) Text(entry),
                                ],
                              ),
                            ),
                            actions: [
                              TextButton(
                                onPressed: () {
                                  Navigator.of(context).pop();
                                },
                                child: Text('Close'),
                              ),
                            ],
                          );
                        },
                      );
                    },
                  ),
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.only(bottom: 20.0),
              child: Text(
                'App Developed By Hem Raj Niraula',
                style: TextStyle(fontSize: 12, color: Colors.grey),
              ),
            ),
          ],
        ),
      ),
    );
  }

  List<String> _getButtonList(String mode) {
    if (mode == 'Basic') {
      return [
        'C',
        '🔙',
        '%',
        '÷',
        '7',
        '8',
        '9',
        '×',
        '4',
        '5',
        '6',
        '-',
        '1',
        '2',
        '3',
        '+',
        '0',
        '00',
        '.',
        '='
      ];
    } else if (mode == 'Student') {
      return [
        'C',
        '🔙',
        '%',
        '÷',
        '7',
        '8',
        '9',
        '×',
        '4',
        '5',
        '6',
        '-',
        '1',
        '2',
        '3',
        '+',
        '0',
        '00',
        '.',
        '=',
        'sin',
        'cos',
        'tan',
        'log',
        'ln',
      ];
    } else {
      return [
        'C',
        '🔙',
        '%',
        '÷',
        '7',
        '8',
        '9',
        '×',
        '4',
        '5',
        '6',
        '-',
        '1',
        '2',
        '3',
        '+',
        '0',
        '00',
        '.',
        '=',
        'Currency Converter',
        'Discount',
        'Loan',
        'VAT',
      ];
    }
  }

  Color _getButtonColor(String buttonText) {
    if (buttonText == 'C' || buttonText == '🔙') {
      return Colors.red;
    } else if (buttonText == '=' ||
        buttonText == '+' ||
        buttonText == '-' ||
        buttonText == '×' ||
        buttonText == '÷') {
      return Colors.blue;
    } else {
      return Colors.grey;
    }
  }
}
